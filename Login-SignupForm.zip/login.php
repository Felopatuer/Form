<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
        <title>Hello, World!</title>
    </head>
    <body>
        <h1>
            Hello, World!
        </h1>
    </body>
</html>
